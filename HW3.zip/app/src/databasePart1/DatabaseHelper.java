package databasePart1;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import application.User;
import application.Question;
import application.Answer;
import application.Message;
import javafx.collections.ObservableList;

/**
 * The DatabaseHelper class is responsible for managing the connection to the
 * database, performing operations such as user registration, login validation,
 * and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "org.h2.Driver";
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";

	// Database credentials
	static final String USER = "sa";
	static final String PASS = "";

	private Connection connection = null;
	private Statement statement = null;
	// PreparedStatement pstmt

	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement();
			// You can use this command to clear the database and restart from fresh.
			// statement.execute("DROP ALL OBJECTS");

			createTables();// Create the necessary tables if they don't exist
			addRoles();
			addEmail();
			addQuestionId();
			// InvitationCodeTimer();
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	private void createTables() throws SQLException {
		String userTable = "CREATE TABLE IF NOT EXISTS cse360users (" + "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, " + "password VARCHAR(255), " + "role VARCHAR(30)) ";
		statement.execute(userTable);

		//create sql table to hold all questions. contains userId of person who asked question, the question itself, and if the question is resolved
		String questionsTable = "CREATE TABLE IF NOT EXISTS Questions (" + "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userId INT, " + "questionText TEXT, " + "isResolved BOOLEAN DEFAULT FALSE) ";
		statement.execute(questionsTable);

		//create sql table to hold all answers. has Id of original question and Id of user who proposed answer, has answer itself and if answer is accepted
		String answersTable = "CREATE TABLE IF NOT EXISTS Answers (" + "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "questionId INT, " + "userId INT, " + "answerText TEXT, " + "isAccepted BOOLEAN DEFAULT FALSE, "
				+ "FOREIGN KEY (questionId) REFERENCES Questions(id), "
				+ "FOREIGN KEY (userId) REFERENCES cse360users(id)) ";
		statement.execute(answersTable);

		//create sql table to hold all messages, has sender and receiver Id's and Id of question that message is being sent about, has the message text and if message was read
		String messagesTable = "CREATE TABLE IF NOT EXISTS Messages (" + "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "senderId INT, " + "receiverId INT, " + "messageText TEXT, " + "isRead BOOLEAN DEFAULT FALSE, "
				+ "FOREIGN KEY (senderId) REFERENCES cse360users(id), "
				+ "FOREIGN KEY (receiverId) REFERENCES cse360users(id)) ";
		statement.execute(messagesTable);

		// Create the invitation codes table, saves roles admin gives new user with code
		String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes (" + "code VARCHAR(10) PRIMARY KEY, "
				+ "isUsed BOOLEAN DEFAULT FALSE) ";
		statement.execute(invitationCodesTable);
	}

	// adds a new column in InvitationCodes table that stores roles given to new
	// users by admin
	public void addRoles() {
		String query = "ALTER TABLE InvitationCodes ADD COLUMN IF NOT EXISTS roles VARCHAR(40)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//adds a new column in cse360users table to hold emails.
	public void addEmail() {
		String query = "ALTER TABLE cse360users ADD COLUMN IF NOT EXISTS email VARCHAR(255)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void addQuestionId() {
		String query = "ALTER TABLE Messages ADD COLUMN IF NOT EXISTS questionId INT";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO cse360users (userName, password, role, email) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.setString(4, user.getEmail());
			pstmt.executeUpdate();
		}
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ? AND email = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.setString(4, user.getEmail());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}

	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
		String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {

			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				// If the count is greater than 0, the user exists
				return rs.getInt(1) > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false; // If an error occurs, assume user doesn't exist
	}

	//function to remove users if they are not an admin
	public boolean removeUser(String userName) {
		String query = "DELETE FROM cse360users WHERE userName = ?";
		if (!getUserRole(userName).contains("admin")) {
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, userName);
				pstmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			return false;
		}
		return false;
	}

	// Adds a new question to the database.
	public void addQuestion(int userId, String questionText) throws SQLException {
		String query = "INSERT INTO Questions (userId, questionText) VALUES (?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			pstmt.setString(2, questionText);
			pstmt.executeUpdate();
		}
	}

	// Adds a new answer to the database.
	public void addAnswer(int questionId, int userId, String answerText) throws SQLException {
		// Check if the userId exists in cse360users
		String userQuery = "SELECT COUNT(*) FROM cse360users WHERE id = ?";
		try (PreparedStatement userStmt = connection.prepareStatement(userQuery)) {
			userStmt.setInt(1, userId);
			ResultSet userRs = userStmt.executeQuery();
			if (userRs.next() && userRs.getInt(1) == 0) {
				throw new SQLException("Invalid userId: " + userId);
			}
		}
		
		

		// Check if the questionId exists in Questions
		String questionQuery = "SELECT COUNT(*) FROM Questions WHERE id = ?";
		try (PreparedStatement questionStmt = connection.prepareStatement(questionQuery)) {
			questionStmt.setInt(1, questionId);
			ResultSet questionRs = questionStmt.executeQuery();
			if (questionRs.next() && questionRs.getInt(1) == 0) {
				throw new SQLException("Invalid questionId: " + questionId);
			}
		}
		String query = "INSERT INTO Answers (questionId, userId, answerText) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionId);
			pstmt.setInt(2, userId);
			pstmt.setString(3, answerText);
			pstmt.executeUpdate();
		}
	}

	// Marks a question as resolved.
	public void markQuestionAsResolved(int questionId) throws SQLException {
		String query = "UPDATE Questions SET isResolved = TRUE WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionId);
			pstmt.executeUpdate();
		}
	}

	//Marks an answer as accepted
	public void markAnswersAccepted(int answerId) throws SQLException {
		String query = "UPDATE Answers SET isAccepted = TRUE WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, answerId);
			pstmt.executeUpdate();
		}
	}
	
	//will show all questions
	public ObservableList<Question> getAllQuestions() {
		ObservableList<Question> questions = FXCollections.observableArrayList();
		String query = "SELECT * FROM Questions ";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
			while (rs.next()) {
				Question question = new Question(rs.getInt("id"), rs.getInt("userId"), rs.getString("questionText"),
						rs.getBoolean("isResolved"));
				questions.add(question);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questions;
	}
	
	//will show all questions user has made
		public ObservableList<Question> getMyQuestions(int userId) {
			ObservableList<Question> questions = FXCollections.observableArrayList();
			String query = "SELECT * FROM Questions WHERE userId = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setInt(1, userId);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					Question question = new Question(rs.getInt("id"), userId, rs.getString("questionText"),
							rs.getBoolean("isResolved"));
					questions.add(question);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return questions;
		}

	// Retrieves all unresolved questions.
	public ObservableList<Question> getUnresolvedQuestions() {
		ObservableList<Question> questions = FXCollections.observableArrayList();
		//String query = "SELECT * FROM Questions WHERE isResolved = FALSE";
		String query = "SELECT q.* FROM Questions q " +
                "LEFT JOIN Answers a ON q.id = a.questionId " +
                "WHERE q.isResolved = FALSE AND a.id IS NULL";
		try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
			while (rs.next()) {
				Question question = new Question(rs.getInt("id"), rs.getInt("userId"), rs.getString("questionText"),
						rs.getBoolean("isResolved"));
				questions.add(question);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questions;
	}

	// Searches for question based on text input
	public ObservableList<Question> searchQuestion(String input) {
		// Final matching questions
		ObservableList<Question> questions = FXCollections.observableArrayList();
		// Temporary
		ArrayList<Question> allQuestions = new ArrayList<>();
		// Input tokenized into words
		String[] words = input.split(" ");
		String query = "SELECT * FROM Questions";
		try (Statement stmt = connection.createStatement()) {
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Question question = new Question(rs.getInt("id"), rs.getInt("userId"), rs.getString("questionText"),
						rs.getBoolean("isResolved"));
				allQuestions.add(question);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
	
		for (Question q : allQuestions) { // Iterates through questions with q being iterator.
			String[] qWords = q.getQuestionText().split(" "); // Places each of the question's words into an array.
			for (String inputW : words) { // Iterates through word array of what the user has inputed.
				for (String questionW : qWords) { // For every question words array...
					if (inputW.equalsIgnoreCase(questionW)) { // Checks if they are the same word.
						questions.add(q);
						break;
					}
				}
				if(questions.contains(q))break;
			}
		}
		return questions;
	}

	// Retrieves all answers for a specific question.
	public ObservableList<Answer> getAnswersForQuestion(int questionId) {
		ObservableList<Answer> answers = FXCollections.observableArrayList();
		String query = "SELECT * FROM Answers WHERE questionId = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Answer answer = new Answer(rs.getInt("id"), rs.getInt("questionId"), rs.getInt("userId"),
						rs.getString("answerText"), rs.getBoolean("isAccepted"));
				answers.add(answer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return answers;
	}

	// Sends a private message from one user to another.
	public void sendMessage(int senderId, int receiverId, int questionId, String messageText) throws SQLException {
		String query = "INSERT INTO Messages (senderId, receiverId, questionId, messageText) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, senderId);
			pstmt.setInt(2, receiverId);
			pstmt.setInt(3, questionId);
			pstmt.setString(4, messageText);
			pstmt.executeUpdate();
		}
	}

	// Retrieves all unread messages for a specific user.
	public ObservableList<Message> getUnreadMessages(int userId) {
		ObservableList<Message> messages = FXCollections.observableArrayList();
		String query = "SELECT * FROM Messages WHERE receiverId = ? AND isRead = FALSE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Message message = new Message(rs.getInt("id"), rs.getInt("senderId"), rs.getInt("receiverId"),
						rs.getInt("questionId"), rs.getString("messageText"), rs.getBoolean("isRead"));
				messages.add(message);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return messages;
	}
	
	//will mark messages as read in database
	public void markAsRead(int messageId) throws SQLException {
		String query = "UPDATE Messages SET isRead = TRUE WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, messageId);
			pstmt.executeUpdate();
		}
	}
	
	//will return all messages based on questionId so users can see all messages people have sent them
	public ObservableList<Message> getMessagesForQuestion(int senderId, int receiverId, int questionId) {
		ObservableList<Message> messages = FXCollections.observableArrayList();
		String query = "SELECT * FROM Messages WHERE senderId = ? AND receiverId = ? AND questionId = ? ";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, senderId);
			pstmt.setInt(2, receiverId);
			pstmt.setInt(3, questionId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Message newMessage = new Message(rs.getInt("id"), rs.getInt("senderId"), rs.getInt("receiverId"),
						rs.getInt("questionId"), rs.getString("messageText"), rs.getBoolean("isRead"));
				messages.add(newMessage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return messages;
	}
	
	//will delete message in database based on message Id
	public void deleteMessage(int messageId) throws SQLException {
		String query = "DELETE FROM Messages WHERE id = ?";
		try(PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, messageId);
			pstmt.executeUpdate();
		}
	}
	
	//will update Message in database
	public void updateMessage(int messageId, String newMessageText) throws SQLException {
		String query = "UPDATE Messages SET messageText = ? WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, newMessageText);
			pstmt.setInt(2, messageId);
			pstmt.executeUpdate();
		}
	}
	
	//obtain userId based on userName
	public int getUserId(String userName) {
		String query = "SELECT id FROM cse360users WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt("id"); // Return the role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0; // If no user exists or an error occurs
	}
	
	//will get userName based on user id
	public String getUserName(int id) {
		String query = "SELECT userName FROM cse360users WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("userName"); // Return the role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // If no user exists or an error occurs
	}
	
	// Delete a question after its been added to the database
	public void deleteQuestion(int questionId) throws SQLException {
		String query = "DELETE FROM Questions WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, questionId);
			pstmt.executeUpdate();
		}
	}
	
	

	// Update a question after it has been added to the database
	public void updateQuestion(int questionId, String newQuestionText) throws SQLException {
		String query = "UPDATE Questions SET questionText = ? WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, newQuestionText);
			pstmt.setInt(2, questionId);
			pstmt.executeUpdate();
		}
	}

	// Delete an answer after its been added to the database
	public void deleteAnswer(int answerId) throws SQLException {
		String query = "DELETE FROM Answers WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, answerId);
			pstmt.executeUpdate();
		}
	}

	// Update an answer after it has been added to the database
	public void updateAnswer(int answerId, String newAnswerText) throws SQLException {
		String query = "UPDATE Answers SET answerText = ? WHERE id = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, newAnswerText);
			pstmt.setInt(2, answerId);
			pstmt.executeUpdate();
		}
	}

	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
		String query = "SELECT role FROM cse360users WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("role"); // Return the role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // If no user exists or an error occurs
	}

	// retrieve email from database
	public String getUserEmail(String userName) {
		String query = "SELECT email FROM cse360users WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("email"); // Return the role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // If no user exists or an error occurs
	}

	// obtain roles given by admin from the database based on invitation code
	public String getInviteRoles(String code) {
		String query = "SELECT roles FROM InvitationCodes WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("roles"); // Return the role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // If no user exists or an error occurs
	}

	// Generates a new invitation code and inserts it into the database, as well as
	// roles admin permit's user to have.
	public String generateInvitationCode(String role) {
		String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
		String query = "INSERT INTO InvitationCodes (code, roles) VALUES (?, ?)";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			pstmt.setString(2, role);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return code;
	}

	// Validates an invitation code to check if it is unused.
	public boolean validateInvitationCode(String code) {
		String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				// Mark the code as used
				markInvitationCodeAsUsed(code);
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
		String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// will delete all invitation codes that are not used after 48 hours
	private void InvitationCodeTimer() {
		String query = "DELETE FROM InvitationCodes WHERE code < '48:00:00'";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Returns result list of all users
	public ObservableList<User> viewUsers() {

		// Array of users containing all the names
		ObservableList<User> userList = FXCollections.observableArrayList();

		String query = "SELECT userName FROM cse360users";
		try (Statement stmt = connection.createStatement()) {
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String name = rs.getString("userName");
				String role = getUserRole(name);
				String email = getUserEmail(name);
				User x = new User(name, "x", role, email);
				userList.add(x);
			}
			;
			return userList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userList;
	}

	// Closes the database connection and statement.
	public void closeConnection() {
		try {
			if (statement != null)
				statement.close();
		} catch (SQLException se2) {
			se2.printStackTrace();
		}
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

}
