package application;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;


/**
 * A test class for verifying the functionality of the {@link Question} and {@link Answer} classes.
 * Includes tests for getters/setters, resolved status, and string representation.
 */
public class HW3Testing {
	
	/**
     * Tests the {@link Question#getId()} and {@link Question#setId(int)} methods.
     * Verifies that:
     * <ul>
     *   <li>The initial ID is correctly set during construction.</li>
     *   <li>The ID can be updated and retrieved accurately.</li>
     * </ul>
     * @throws AssertionError if any verification fails.
     */
    @Test
    @DisplayName("Test Question ID getter and setter")
    public void IdGetandSetQuestiontest() {
        try {
            System.out.println("\nRunning Test: Question ID getter and setter");
            Question testQ = new Question(1, 1, "Hello?", false);
            
            // Test initial ID
            assertInitialId(testQ, 1);
            
            // Test ID update
            testIdUpdate(testQ, 2);
            
            System.out.println("Test passed: Question ID getter and setter works correctly");
        } catch (AssertionError e) {
            handleFailure("Question ID getter and setter", e);
            throw e; // Re-throw to mark test as failed
        }
    }

    /**
     * Tests the {@link Question#getUserId()} and {@link Question#setUserId(int)} methods.
     * Verifies that:
     * <ul>
     *   <li>The initial user ID (question author) is correctly set.</li>
     *   <li>The user ID can be updated and retrieved accurately.</li>
     * </ul>
     * @throws AssertionError if any verification fails.
     */
    @Test
    @DisplayName("Test Question user ID getter and setter")
    public void userIdGetandSetQuestiontest() {
        try {
            System.out.println("\nRunning Test: Question user ID getter and setter");
            Question testQ = new Question(1, 1, "Hello?", false);
            
            // Test initial user ID
            assertInitialUserId(testQ, 1);
            
            // Test user ID update
            testUserIdUpdate(testQ, 2);
            
            System.out.println("Test passed: Question user ID getter and setter works correctly");
        } catch (AssertionError e) {
            handleFailure("Question user ID getter and setter", e);
            throw e;
        }
    }

    /**
     * Tests the {@link Question#isResolved()} and {@link Question#setResolved(boolean)} methods.
     * Verifies that:
     * <ul>
     *   <li>The initial resolved status is correctly set to {@code false}.</li>
     *   <li>The status can be updated to {@code true} and retrieved accurately.</li>
     * </ul>
     * @throws AssertionError if any verification fails.
     */
    @Test
    @DisplayName("Test Question resolved status")
    public void questionResolvedtest() {
        try {
            System.out.println("\nRunning Test: Question resolved status");
            Question testQ = new Question(1, 1, "Hello?", false);
            
            // Test initial resolved status
            assertInitialResolvedStatus(testQ, false);
            
            // Test resolved status update
            testResolvedStatusUpdate(testQ, true);
            
            System.out.println("Test passed: Question resolved status changes correctly");
        } catch (AssertionError e) {
            handleFailure("Question resolved status", e);
            throw e;
        }
    }

    /**
     * Tests the {@link Question#toString()} method.
     * Verifies that the returned string matches the expected format:
     * <pre>
     * "Question{id=1, userId=1, questionText='Hello?', isResolved=false}"
     * </pre>
     * @throws AssertionError if the output format is incorrect.
     */
    @Test
    @DisplayName("Test Question toString() method")
    public void AnswerToStringtest() {
        try {
            System.out.println("\nRunning Test: Question toString() method");
            Question testQ = new Question(1, 1, "Hello?", false);
            String expected = "Question{id=1, userId=1, questionText='Hello?', isResolved=false}";
            
            assertToStringOutput(testQ, expected);
            
            System.out.println("Test passed: Question toString() produces correct output");
        } catch (AssertionError e) {
            handleFailure("Question toString() method", e);
            throw e;
        }
    }

    /**
     * Tests the {@link Answer#getUserId()} and {@link Answer#setUserId(int)} methods.
     * Verifies that:
     * <ul>
     *   <li>The initial user ID (answer author) is correctly set.</li>
     *   <li>The user ID can be updated and retrieved accurately.</li>
     * </ul>
     * @throws AssertionError if any verification fails.
     */
    @Test
    @DisplayName("Test Answer user ID getter and setter")
    public void userIdGetandSetAnswertest() {
        try {
            System.out.println("\nRunning Test: Answer user ID getter and setter");
            Answer testA = new Answer(1, 1, 1, "Hi", false);
            
            // Test initial user ID
            assertInitialAnswerUserId(testA, 1);
            
            // Test user ID update
            testAnswerUserIdUpdate(testA, 2);
            
            System.out.println("Test passed: Answer user ID getter and setter works correctly");
        } catch (AssertionError e) {
            handleFailure("Answer user ID getter and setter", e);
            throw e;
        }
    }

    // Helper methods for better organization and reuse
    private void assertInitialId(Question question, int expectedId) {
        System.out.println("Verifying initial ID value...");
        assertEquals(expectedId, question.getId(), 
            "Initial ID verification failed. Expected: " + expectedId + 
            ", Actual: " + question.getId());
    }

    private void testIdUpdate(Question question, int newId) {
        System.out.println("Setting new ID value to " + newId + "...");
        question.setId(newId);
        
        System.out.println("Verifying updated ID value...");
        assertEquals(newId, question.getId(), 
            "ID update verification failed. Expected: " + newId + 
            ", Actual: " + question.getId());
    }

    private void assertInitialUserId(Question question, int expectedUserId) {
        System.out.println("Verifying initial user ID value...");
        assertEquals(expectedUserId, question.getUserId(), 
            "Initial user ID verification failed. Expected: " + expectedUserId + 
            ", Actual: " + question.getUserId());
    }

    private void testUserIdUpdate(Question question, int newUserId) {
        System.out.println("Setting new user ID value to " + newUserId + "...");
        question.setUserId(newUserId);
        
        System.out.println("Verifying updated user ID value...");
        assertEquals(newUserId, question.getUserId(), 
            "User ID update verification failed. Expected: " + newUserId + 
            ", Actual: " + question.getUserId());
    }

    private void assertInitialResolvedStatus(Question question, boolean expectedStatus) {
        System.out.println("Verifying initial resolved status...");
        assertEquals(expectedStatus, question.isResolved(), 
            "Initial resolved status verification failed. Expected: " + expectedStatus + 
            ", Actual: " + question.isResolved());
    }

    private void testResolvedStatusUpdate(Question question, boolean newStatus) {
        System.out.println("Setting resolved status to " + newStatus + "...");
        question.setResolved(newStatus);
        
        System.out.println("Verifying updated resolved status...");
        assertEquals(newStatus, question.isResolved(), 
            "Resolved status update verification failed. Expected: " + newStatus + 
            ", Actual: " + question.isResolved());
    }

    private void assertToStringOutput(Question question, String expected) {
        System.out.println("Verifying toString() output matches expected format...");
        assertEquals(expected, question.toString(), 
            "toString() verification failed.\nExpected: " + expected + 
            "\nActual: " + question.toString());
    }

    private void assertInitialAnswerUserId(Answer answer, int expectedUserId) {
        System.out.println("Verifying initial user ID value...");
        assertEquals(expectedUserId, answer.getUserId(), 
            "Initial Answer user ID verification failed. Expected: " + expectedUserId + 
            ", Actual: " + answer.getUserId());
    }

    private void testAnswerUserIdUpdate(Answer answer, int newUserId) {
        System.out.println("Setting new user ID value to " + newUserId + "...");
        answer.setUserId(newUserId);
        
        System.out.println("Verifying updated user ID value...");
        assertEquals(newUserId, answer.getUserId(), 
            "Answer User ID update verification failed. Expected: " + newUserId + 
            ", Actual: " + answer.getUserId());
    }

    private void handleFailure(String testName, AssertionError error) {
        System.out.println("Test FAILED: " + testName);
        System.out.println("Failure Reason: " + error.getMessage());
        System.out.println("Stack Trace:");
        error.printStackTrace(System.out);
    }

    // Method to verify tests fail when they should
    @Test
    @DisplayName("Verify failure detection works")
    void testFailureDetection() {
        try {
            System.out.println("\nRunning Test: Verify failure detection");
            
            // This test should fail
            Question testQ = new Question(1, 1, "Hello?", false);
            assertNotEquals(1, testQ.getId(), 
                "This test should fail because the ID is actually 1");
            
            // If we get here, the test didn't fail as expected
            fail("Failure detection test didn't fail as expected");
        } catch (AssertionError e) {
            System.out.println("Test passed: Correctly detected failure case");
            // Expected failure - test passes
        }
    }
}