package application;

import static org.junit.Assert.*;

import org.junit.Test;

import databasePart1.DatabaseHelper;

public class TP2_Testing {

	@Test
	public void IdGetandSetQuestiontest() {
		Question testQ = new Question(1, 1, "Hello?", false);
		assertEquals(1, testQ.getId());
		testQ.setId(2);
		assertEquals(2, testQ.getId());
	}
	@Test
	public void userIdGetandSetQuestiontest() {
		Question testQ = new Question(1, 1, "Hello?", false);
		assertEquals(1, testQ.getUserId());
		testQ.setUserId(2);
		assertEquals(2, testQ.getUserId());
	}
	@Test
	public void questionTextGetandSettest() {
		Question testQ = new Question(1, 1, "Hello?", false);
		assertEquals("Hello?", testQ.getQuestionText());
		testQ.setQuestionText("Goodbye?");
		assertEquals("Goodbye?", testQ.getQuestionText());
	}
	@Test
	public void questionResolvedtest() {
		Question testQ = new Question(1, 1, "Hello?", false);
		assertEquals(false, testQ.isResolved());
		testQ.setResolved(true);
		assertEquals(true, testQ.isResolved());
	}
	@Test
	public void questionToStringtest() {
		Question testQ = new Question(1, 1, "Hello?", false);
		assertEquals("Question{id=1, userId=1, questionText='Hello?', isResolved=false}", testQ.toString());
	}
	

	
	
	
	@Test
	public void IdGetandSetAnswertest() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals(1, testA.getId());
		testA.setId(2);
		assertEquals(2, testA.getId());
	}
	@Test
	public void userIdGetandSetAnswertest() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals(1, testA.getUserId());
		testA.setUserId(2);
		assertEquals(2, testA.getUserId());
	}
	@Test
	public void questionIdGetandSetAnswertest() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals(1, testA.getQuestionId());
		testA.setQuestionId(2);
		assertEquals(2, testA.getQuestionId());
	}
	@Test
	public void answerTextGetandSetText() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals("Hi", testA.getAnswerText());
		testA.setAnswerText("Yo");
		assertEquals("Yo", testA.getAnswerText());
	}
	@Test
	public void answerisAcceptedTest() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals(false, testA.isAccepted());
		testA.setAccepted(true);
		assertEquals(true, testA.isAccepted());
	}
	@Test
	public void answerToStringtest() {
		Answer testA = new Answer(1, 1, 1, "Hi", false);
		assertEquals("Answer{id=1, questionId=1, userId=1, answerText='Hi', isAccepted=false}", testA.toString());
	}
	@Test
	public void getReceiverIdMessageTest() {
		Message testM = new Message(1, 1, 1, 1, "Hi", false);
		assertEquals(1, testM.getReceiverId());
	}
	@Test
	public void messageTextGetandSetText() {
		Message testM = new Message(1, 1, 1, 1, "Hello", false);
		assertEquals("Hello", testM.getMessageText());
		testM.setMessageText("I can help");
		assertEquals("I can help", testM.getMessageText());
	}
	
	
}
